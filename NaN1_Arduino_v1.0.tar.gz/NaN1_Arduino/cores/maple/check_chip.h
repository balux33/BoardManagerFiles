#ifndef _check_chip_H_
#define _check_chip_H_

#include "Arduino.h"

bool check_fake_chip();  //return true if gd32f103 detected  or false if genuine stm32f103


#endif