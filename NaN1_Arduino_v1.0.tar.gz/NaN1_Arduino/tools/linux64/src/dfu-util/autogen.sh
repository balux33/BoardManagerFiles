#! /bin/sh
autoreconf -v -i
